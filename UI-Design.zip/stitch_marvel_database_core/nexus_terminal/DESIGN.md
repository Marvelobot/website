---
name: Nexus Terminal
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#e4beba'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#ab8986'
  outline-variant: '#5b403e'
  surface-tint: '#ffb3ad'
  primary: '#ffb3ad'
  on-primary: '#68000a'
  primary-container: '#ff5451'
  on-primary-container: '#5c0008'
  inverse-primary: '#b91a24'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#69d8d4'
  on-tertiary: '#003736'
  tertiary-container: '#24a09d'
  on-tertiary-container: '#00302e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#930013'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#87f4f0'
  tertiary-fixed-dim: '#69d8d4'
  on-tertiary-fixed: '#00201f'
  on-tertiary-fixed-variant: '#00504e'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  mono-data:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  grid-gutter: 24px
  side-margin: 40px
---

## Brand & Style
The design system is a high-fidelity, cinematic interface designed for a premium game database. It evokes the sophisticated "Heads-Up Display" (HUD) aesthetics found in Stark Industries or S.H.I.E.L.D. technology. 

The personality is authoritative, advanced, and immersive. It targets power users who require data density without sacrificing the epic, atmospheric feel of the Marvel universe. The style is a hybrid of **Glassmorphism** and **Modern Corporate**, utilizing translucent layers, vibrant accent glows, and precision-engineered geometry to create a sense of depth and technical superiority.

## Colors
The palette is rooted in a "Deep Space" dark mode. 
- **Primary Accent (Power Red):** Used for critical data, active states, and high-energy UI elements. 
- **Secondary Accent (Stark Gold):** Used for legendary status items, rare database entries, and highlighting premium features.
- **Surface Palette:** A range of slates and charcols provide the foundation. 
- **Glass Effects:** Backgrounds use semi-transparent variations of the surface colors with a high `backdrop-filter: blur(12px)` to maintain legibility over cinematic character art.
- **Glows:** Accent colors are applied as low-opacity box-shadows (0 0 15px) to simulate glowing hardware indicators.

## Typography
The system utilizes **Outfit** for structural headings to provide a modern, geometric feel that leans into the "tech-noir" aesthetic. **Inter** is used for all functional body copy and data points to ensure maximum readability in dense tables and character stats. 

Uppercase labels with slight letter spacing are used for "System Feedback" and "Status Indicators" to mimic industrial military displays. For numerical data, Inter's tabular spacing provides a clean, monospaced feel without losing the contemporary sans-serif vibe.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. The sidebar remains at a fixed 280px width, while the main content area utilizes a 12-column fluid grid. 

- **The 8px Rhythm:** All padding and margins are increments of 8px. 
- **Modular Cards:** Data is grouped into cards that stack vertically on mobile and span varied column counts (4, 6, or 12) on desktop.
- **Safe Areas:** A generous 40px margin is maintained around the screen perimeter to keep the UI feeling like a framed terminal window rather than a standard web page.

## Elevation & Depth
Depth is achieved through **Tonal Stacking** and **Glassmorphism** rather than traditional heavy shadows.

- **Level 0 (Floor):** Deep Charcoal (#0F172A).
- **Level 1 (Panels):** Slate (#1E293B) with a subtle 1px border (#334155).
- **Level 2 (Active Modals/Popovers):** Translucent background (RGBA 30, 41, 59, 0.7) with `backdrop-filter: blur(16px)` and a vibrant 1px border using the accent color at 30% opacity.
- **Depth Cues:** Interactive elements use a "Inner Glow" effect when hovered, making them feel like active touchpoints on a backlit console.

## Shapes
The design system employs a **Rounded** shape language (0.5rem / 8px). This strikes a balance between the aggressive "sharp" edges of retro-tech and the "soft" consumer electronics of today. 

- **Outer Containers:** Use `rounded-xl` (24px) for the main dashboard viewport.
- **Buttons and Inputs:** Use a standard 8px radius.
- **Avatar/Hero Frames:** Utilize a subtle "clipped corner" effect via CSS clip-path on character portraits to enhance the "S.H.I.E.L.D. ID card" aesthetic.

## Components
- **Buttons:** Primary buttons are solid "Power Red" with a subtle hover glow. Secondary buttons are "Ghost" style with thin 1px borders and high-blur backdrops.
- **Data Chips:** Small, pill-shaped indicators for "Power Levels" or "Affiliations." Use low-opacity backgrounds with high-saturation text.
- **Status Bars:** Sleek, horizontal progress bars for character health/stats. Use a subtle pulse animation for "charging" states.
- **Input Fields:** Dark, recessed backgrounds with a bright 1px bottom-border highlight that expands to a full border on focus.
- **Database Cards:** Large hero-focused cards with image backgrounds, utilizing a bottom-up gradient mask to ensure text legibility over character artwork.
- **The "Scanner" List:** List items that feature a vertical accent line on the left to indicate selection, mimicking a scrolling radar or system log.